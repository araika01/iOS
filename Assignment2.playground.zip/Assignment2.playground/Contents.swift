// Easy Tasks

// 1
let fruits = ["apple", "banana", "kiwi", "Cherry", "Pear"]
print(fruits[2])

// 2
var favoriteNumbers: Set = [7, 13, 21]
favoriteNumbers.insert(44)
print(favoriteNumbers)

// 3
var languages: [String: Int] = ["Swift": 2014, "Python": 1991, "Java": 1995]
print(languages["Swift"]!)

// 4
var colors = ["red", "blue", "yellow", "purple"]
colors[1] = "green"
print(colors)

// Medium Tasks

// 1
let setA: Set = [1, 2, 3, 4]
let setB: Set = [3, 4, 5, 6]
print(setA.intersection(setB))

// 2
var scores = [
    "Aray": 96, "Ayana": 90, "Arman": 93
]
scores.updateValue(98, forKey: "Aray")
print(scores)

// 3
let arr1 = ["apple", "banana"]
let arr2 = ["cherry", "date"]
let merged = arr1 + arr2
print(merged)

// Hard Tasks

// 1
var populations = ["USA": 331000000, "China": 1400000000, "India": 1380000000]
populations.updateValue(214000000, forKey: "Brazil")
print(populations)

// 2
let animals1: Set = ["cat", "dog"]
let animals2: Set = ["dog", "mouse"]
let union = animals1.union(animals2)
let result = union.subtracting(animals2)
print(result)

// 3
let studentsGrades: [String: [Int]] = [
    "Aray": [90, 85, 88],
    "Ayana": [78, 92, 80],
    "Arman": [85, 89, 94]
]

print(studentsGrades["Arman"]![1])
