// =============================================================
//  Station ALMA-7, Part III: The Repair Fleet
//  iOS Mobile Development · Module 5 · Lab Assignment
//
//  How to use:
//   • Xcode: File → New → Playground → Blank, replace everything
//     with this file's contents.
//   • Terminal: swift ALMA7_Part3_Starter.swift
//
//  Rules:
//   • Do NOT modify the STARTER DATA section. LegacyBeacon in
//     particular must be reached with an extension, not edited.
//   • `!` (force unwrap) is forbidden: −0.5 points each.
//   • No map / filter / reduce / compactMap.
//   • The Health Rule must exist in exactly ONE place in this file.
// =============================================================


// MARK: - =================== STARTER DATA ===================
// MARK: - Do not modify anything in this section

/// Drone records recovered from the fleet registry.
/// One `kind` does not correspond to any drone type you will build.
let fleetData: [(kind: String, id: String, charge: Int)] = [
    (kind: "welder",  id: "W-1", charge: 80),
    (kind: "scanner", id: "S-1", charge: 45),
    (kind: "cargo",   id: "C-1", charge: 100),
    (kind: "welder",  id: "W-2", charge: 15),
    (kind: "scanner", id: "S-2", charge: 60),
    (kind: "tug",     id: "T-1", charge: 50)
]

/// Hull sensors. These are NOT drones — they never move and never work a shift.
let sensorData: [(id: String, charge: Int)] = [
    (id: "hull-cam", charge: 12),
    (id: "thermal",  charge: 77)
]

/// Hardware from the original station. You may not add anything to this
/// declaration — no methods, no protocols, no properties.
struct LegacyBeacon {
    let name: String
    let signalStrength: Int
}

let beacon = LegacyBeacon(name: "ALMA-BEACON", signalStrength: 8)

print("Fleet registry online: \(fleetData.count) drone records, \(sensorData.count) sensors, beacon \(beacon.name).")

// MARK: - ================= END OF STARTER DATA =================


// MARK: - =================== YOUR SOLUTION ===================
// Uncomment each declaration when you start working on it.


// MARK: Level 1 · The Power Cell

// Why a class and not a struct here?  ->
// PowerCell must be a reference type so the drone's battery is shared and mutations persist; a struct would copy on every access.

final class PowerCell {
    private var charge: Int
    
    init(charge: Int) {
        if charge < 0 {
            self.charge = 0
        } else if charge > 100 {
            self.charge = 100
        } else {
            self.charge = charge
        }
    }
    
    func level() -> Int {
        return charge
    }
    
    func spend(_ amount: Int) -> Bool {
        if amount <= 0 {
            return false
        }
        
        if amount > charge {
            return false
        }
        
        charge -= amount
        return true
        
    }
    
    func recharge(by amount: Int) {
        if amount <= 0 {
            return
        }
        
        charge = min(charge + amount, 100)
    }
}

// Encapsulation proof (leave this commented, with the compiler error):
// cell.charge = 100

// error: 'charge' is inaccessible due to 'private' protection level


// MARK: Level 2 · The Fleet

// 2.1  What does `final` on runOnce() buy you?  ->
// final locks the shift ritual: subclasses may change cost and work, but cannot bypass the spend-then-work sequence

class Drone {
    let id: String
    let cell: PowerCell
    
    init(id: String, cell: PowerCell) {
        self.id = id
        self.cell = cell
    }
    
    var powerCost: Int { return 10 }
    
    var statusLine: String {
        return "\(id): \(cell.level())% \(cell.level().powerBar)"
    }
    
    func performTask() -> Int { return 0 }
    
    final func runOnce() -> Int {
        if !cell.spend(powerCost) {
            return 0
        }
        
        return performTask()
    }
}

// 2.2
final class WelderDrone: Drone {
    override var powerCost: Int {
        return 25
    }
    
    override func performTask() -> Int {
        return 40
    }
    
    func weldSeam() -> String {
        return "\(id): seam welded"
    }
}

class ScannerDrone: Drone {
    override var powerCost: Int {
        return 10
    }
    
    override func performTask() -> Int {
        return 15
    }
    
    override var statusLine: String {
        return super.statusLine + " [scanner]"
    }
}

final class CargoDrone: Drone {
    override var powerCost: Int {
        return 20
    }
    
    override func performTask() -> Int {
        return 25
    }
}

// 2.3
func makeDrone(kind: String, id: String, charge: Int) -> Drone? {
    let cell = PowerCell(charge: charge)
    
    if kind == "welder" {
        return WelderDrone(id: id, cell: cell)
    } else if kind == "scanner" {
        return ScannerDrone(id: id, cell: cell)
    } else if kind == "cargo" {
        return CargoDrone(id: id, cell: cell)
    } else {
        return nil
    }
}

var fleet: [Drone] = []

for record in fleetData {
    if let drone = makeDrone(kind: record.kind, id: record.id, charge: record.charge) {
        fleet.append(drone)
    } else {
        print("Warning: skipping unknown drone kind '\(record.kind)' ('id: \(record.id))")
    }
}

print("Fleet assembled: \(fleet.count) drones")


// MARK: Level 3 · The Shift

func runShift(_ fleet: [Drone], rounds: Int) -> Int {
    var totalWork = 0
    
    for _ in 0..<rounds {
        for drone in fleet {
            totalWork += drone.runOnce()
        }
    }
    
    return totalWork
}

let A = runShift(fleet, rounds: 3)
for drone in fleet {
    print (drone.statusLine)
}

var B = 0
for drone in fleet {
    B += drone.cell.level()
}

var C = 0
for drone in fleet {
    if drone.cell.level() >= drone.powerCost {
        C += 1
    }
}

print("Drones that can still run one more task: \(C)")

// MARK: Level 4 · Diagnostics

// 4.1
protocol Diagnosable {
    var componentID: String { get }
    var statusCode: Int { get }
    func diagnose() -> String
}

// 4.2
protocol Rechargeable {
    mutating func recharge(by amount: Int)
}

// Why does Drone implement recharge(by:) without `mutating`?  ->
// Drone is a class: its method mutate the shared instance directly, so 'mutating' is not required, while structs are value types and must mark me thoods that change 'self' as 'mutating'

struct SensorModule: Diagnosable, Rechargeable {
    let id: String
    var chargeLevel: Int
    
    var componentID: String {
        return id
    }
    
    var statusCode: Int {
        return statusCode(for: chargeLevel)
    }
    
    mutating func recharge(by amount: Int) {
        if amount <= 0 { return }
        chargeLevel = min(chargeLevel + amount, 100)
    }
}

var sensors: [SensorModule] = []
for record in sensorData {
    sensors.append(SensorModule(id: record.id, chargeLevel: record.charge))
}

// 4.3
// Why could [Drone] never have held the sensors?  ->
// SensorModule is a struct, not a Drone subclass, inheritance only units classes in one hirarchy. A protocol type, [Diagnosable], can hold any conforming type - class, struct, or an unmodifiable legacy type.

func diagnosticsReport(_ components: [Diagnosable]) -> String {
    var report = ""
    for component in components {
        report += component.diagnose() + "\n"
    }
    return report
}

extension Drone: Diagnosable {
    var componentID: String {
        return id
    }
    
    var statusCode: Int {
        return statusCode(for: cell.level())
    }
}

extension Drone: Rechargeable {
    func recharge(by amount: Int) {
        cell.recharge(by: amount)
    }
}

// MARK: Level 5 · Shared Behaviour

// 5.1 · default diagnose() + the single home of the Health Rule
extension Diagnosable {
    func statusCode(for level: Int) -> Int {
        if level < 20 { return 2 }
        if level < 50 { return 1}
        return 0
    }
    
    func diagnose() -> String {
        return "\(componentID): code \(statusCode)"
    }
}
    

// 5.2 · the beacon you cannot edit
extension LegacyBeacon: Diagnosable {
    var componentID: String {
        return name
    }
    
    var statusCode: Int {
        return statusCode(for: signalStrength)
    }
    
    func diagnose() -> String {
        return "LEGACY \(componentID): signal \(signalStrength), code \(statusCode)"
    }
}

var components: [Diagnosable] = []

for drone in fleet {
    components.append(drone)
}
for sensor in sensors {
    components.append(sensor)
}
components.append(beacon)

var D = 0
for component in components {
    D += component.statusCode
}

print(diagnosticsReport(components))
print("Mission fragment D = \(D)")

// 5.3
extension Int {
    var powerBar: String {
        var units = self / 10
        if units < 0 { units = 0 }
        if units > 10 { units = 10 }
        
        var bar = ""
        for i in 0..<10 {
            if i < units {
                bar += "#"
            } else {
                bar += "."
            }
        }
        return bar
    }
}


// MARK: Level 6 · Incident Reports
// Two of these do not compile. Two compile and lie.
// For each: expectation, actual behaviour, the language rule, the fix.

/*
// Report 1
class PatchDrone: Drone {
    func performTask() -> Int {
        return 30
    }
}

// Report 2
final class HeavyWelder: WelderDrone {
    override func runOnce() -> Int {
        return 999
    }
}

// Report 3
let reportFleet: [Drone] = [WelderDrone(id: "W-9", cell: PowerCell(charge: 100))]
let first = reportFleet[0]
print(first.weldSeam())

// Report 4
protocol Labelled {
    var componentID: String { get }
}

extension Labelled {
    func label() -> String { "generic component" }
}

struct Thruster: Labelled {
    let componentID: String
    func label() -> String { "thruster \(componentID)" }
}

let parts: [Labelled] = [Thruster(componentID: "T-1")]
print(parts[0].label())
*/

// Report 1
class PatchDrone: Drone {
    override func performTask() -> Int {
        return 30
    }
}

// Expectation: PatchDrone overrides performTask() and returns 30
// Actual behaviour: Overriding declaration requires an 'override' keyword
// Language rule: If a subclass method has the same signature as a superclass method, Swift requires the override keyword — it is an explicit confirmation of the intent to override
// Fix: add override


// Report 2
final class HeavyWelder: Drone {
    override var powerCost: Int { return 50 }
    override func performTask() -> Int { return 999 }
}

// Expectation: HeavyWelder returns 999 from runOnce(), bypassing the normal shift logic
// Actual behaviour: Inheritance from a final class 'WelderDrone' and Instance method overrides a 'final' instance method
// Language rule: final on a class forbids subclassing. final on a method forbids overriding. Both mechanisms protect behaviour from being changed by subclasses
// Fix: Do not subclass WelderDrone; make HeavyWelder a direct subclass of Drone and override powerCost / performTask instead of runOnce()

// Report 3
let reportFleet: [Drone] = [WelderDrone(id: "W-9", cell: PowerCell(charge: 100))]
let first = reportFleet[0]
if let welder = first as? WelderDrone {
    print(welder.weldSeam())
}

// Expectation: first is a WelderDrone, so weldSeam() is callable
// Actual behaviour: Value of type 'Drone' has no member 'weldSeam'
// Language rule: The array is declared as [Drone]. The compiler sees the static type of the element — Drone — and only allows calling what Drone has. weldSeam() exists only on WelderDrone, so the compiler cannot see it
// Fix: use as? to safely cast to WelderDrone

// Report 4
protocol Labelled {
    var componentID: String { get }
    func label() -> String
}

extension Labelled {
    func label() -> String { "generic component" }
}

struct Thruster: Labelled {
    let componentID: String
    func label() -> String { "thruster \(componentID)" }
}

let parts: [Labelled] = [Thruster(componentID: "T-1")]
print(parts[0].label())

// Expectation: Prints "thruster T-1" — Thruster's own label()
// Actual behaviour: Compiles. Prints "generic component"
// Language rule: Static vs dynamic dispatch. A method that is not declared in the protocol but lives only in an extension is not added to the witness table. When called through a protocol-typed value, Swift uses static dispatch and calls the extension's implementation, ignoring the concrete type's method.
// Fix: Declare label() inside the protocol — then dispatch becomes dynamic

// MARK: Finale · Mission Code

let missionCode = "\(A)-\(B)-\(C)-\(D)"
print("MISSION CODE: \(missionCode)")


// MARK: Bonus

// Two ways to forbid using Drone directly; a protocol-based redesign;
// Forbid using Drone directly private init


// MARK: - ================= DEFENSE QUESTIONS =================
/*
 1. Why does a class satisfy a `mutating` protocol requirement without the
    keyword, while a struct must write it?
 A class is a reference type, so its methods already mutate the shared instance — mutating is unnecessary (and forbidden). A struct is a value type, so it must mark methods that change self as mutating

 2. One thing inheritance does that protocols cannot, and one thing
    protocols do that inheritance cannot:
 Inheritance can share stored properties and initializers with subclasses; protocols can unite a class and a struct (or an unmodifiable type) under one contract and one array

 3. What does `final` prevent, and what did it protect in runOnce()?
 final prevents overriding and subclassing. On runOnce() it protected the shift ritual so no subclass could bypass the "spend power, then work" sequence

 4. In Report 4, why did the protocol extension's method win?
 Because label() was not a protocol requirement, only an extension method — so it is dispatched statically, and the extension's version wins over Thruster's

*/

