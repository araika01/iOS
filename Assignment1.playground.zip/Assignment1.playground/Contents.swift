// Step 1
let firstName = "Aray"
let lastName = "Zhumat"
let age = 20
let birthYear = 2006
let isStudent = true
let height = Double(167)
let weight = Double(50)
let email = "arai.zhumat@mail.ru"

let currentYear = 2026
let age1 = currentYear - birthYear


// Step 2
let hobby = "Reading books"
let hobbies = ["Reading books", "Singing", "Cooking"]
let numberOfHobbies = 3
let favoriteNumber = 5
let isHobbyCreative = true

let favoriteBook = "And Then There Were None"
let author = "Agata Christie"
let bookGenre = "Detective"

let favoriteCookingDish = "Pasta"

// Step 3
let lifeStory = """
My name is \(firstName) \(lastName). I am \(age) years old, born in \(birthYear). I am currently \(isStudent ? "a student" : "not a student"). I have several hobbies, but a special one for me is \(hobby), which is \(isHobbyCreative ? "a creative" : "a non-creative") hobby. My favorite book is "\(favoriteBook)", by \(author), which is a \(bookGenre) novel. I have \(numberOfHobbies) hobbies in total, which are \(hobbies.joined(separator: ", ")). I also enjoy cooking \(favoriteCookingDish). My favorite number is \(favoriteNumber).
"""

// Step 4
print(lifeStory)

// Bonus task
let 👩🏻‍💻 = "iOS Developer"
let country = "🇺🇸 U.S."
let futureGoals = """
In the future I want to gain experience and work as  \(👩🏻‍💻). In addition, I want to travel across the world, especially in \(country).
"""

print(futureGoals)
