import Foundation
// =============================================================
//  Station ALMA-7, Part II: The Teleporter Incident
//  iOS Mobile Development · Module 4 · Lab Assignment
//
//  How to use:
//   • Xcode: File → New → Playground → Blank, replace everything
//     with this file's contents.
//   • Terminal: swift ALMA7_Part2_Starter.swift
//
//  Rules:
//   • Do NOT modify the STARTER DATA section.
//   • `!` (force unwrap) is forbidden: −0.5 points each.
//   • No map / filter / reduce / compactMap.
//   • Default to struct. Use class only where the task says so.
// =============================================================


// MARK: - =================== STARTER DATA ===================
// MARK: - Do not modify anything in this section

/// Splits a line into fields.
/// fields("crate:101:120")            -> ["crate", "101", "120"]
/// fields("livestock:lab mice:12:2")  -> ["livestock", "lab mice", "12", "2"]
/// fields("junk")                     -> ["junk"]
func fields(_ line: String, separatedBy separator: Character = ":") -> [String] {
    var result: [String] = []
    var current = ""
    for character in line {
        if character == separator {
            result.append(current)
            current = ""
        } else {
            current.append(character)
        }
    }
    result.append(current)
    return result
}

/// Cargo manifest as recovered from the damaged recorder.
let rawManifest = [
    "crate:101:120",
    "container:KZ-ALM-7:340",
    "livestock:lab mice:12:2",
    "???-corrupted-line",
    "crate:102:75",
    "container:KZ-ALM-9:410",
    "livestock:ficus:3:5",
    "crate:103:260",
    "crate:104:abc",
    ""
]

/// Oxygen readings. One of these deck names is not a real deck.
let deckReadings: [(deck: String, oxygen: Int)] = [
    (deck: "bridge",     oxygen: 78),
    (deck: "lab",        oxygen: 64),
    (deck: "greenhouse", oxygen: 55),
    (deck: "cargo",      oxygen: 12),
    (deck: "medbay",     oxygen: 90),
    (deck: "engine",     oxygen: 41)
]

/// Crew records, straight from the personnel file.
let crewData: [(name: String, deck: String, oxygen: Int)] = [
    (name: "Timur",   deck: "engine", oxygen: 62),
    (name: "Dana",    deck: "lab",    oxygen: 48),
    (name: "Aigerim", deck: "bridge", oxygen: 91),
    (name: "Nurlan",  deck: "cargo",  oxygen: 17)
]

print("ALMA-7 recorder online: \(rawManifest.count) manifest lines, \(deckReadings.count) readings, \(crewData.count) crew records.")

// MARK: - ================= END OF STARTER DATA =================


// MARK: - =================== YOUR SOLUTION ===================
// Uncomment each declaration when you start working on it.


// MARK: Level 1 · The Deck Register

// 1.1
enum Deck: String, CaseIterable {
    case bridge, lab, cargo, medbay, engine
    
    var evacuationPriority: Int {
        switch self {
        case .bridge: return 1
        case .medbay: return 2
        case .lab: return 3
        case .engine: return 4
        case .cargo: return 5
            
        }
    }
}

for deck in Deck.allCases {
    print("\(deck.rawValue) -> prioriy \(deck.evacuationPriority)")
}

// 1.2
enum AlarmLevel: Int {
    case green = 0
    case yellow, orange, red
    static func level(forTotalMass mass: Int) -> AlarmLevel {
        let step = mass / 500
        if step >= 3 {
            return red
        }
        return AlarmLevel(rawValue: step) ?? .green
    }
}

print(AlarmLevel.level(forTotalMass: 0))
print(AlarmLevel.level(forTotalMass: 499))
print(AlarmLevel.level(forTotalMass: 940))
print(AlarmLevel.level(forTotalMass: 990))
print(AlarmLevel.level(forTotalMass: 1000))
print(AlarmLevel.level(forTotalMass: 1300))
print(AlarmLevel.level(forTotalMass: 4000))

// MARK: Level 2 · The Manifest

// 2.1
enum ManifestEntry {
    case crate(id: Int, massKg: Int)
    case container(code: String, massKg: Int)
    case livestock(species: String, count: Int, massPerUnitKg: Int)
    case unknown(raw: String)
}

// 2.2
func parseEntry(_ line: String) -> ManifestEntry {
    let parts = fields(line)
    guard let tag = parts.first else {
        return .unknown(raw: line)
    }
    
    switch tag {
    case "crate":
        guard parts.count == 3,
              let id = Int(parts[1]),
              let mass = Int(parts[2]) else {
            return .unknown(raw: line)
        }
        return .crate(id: id, massKg: mass)
        
    case "container":
        guard parts.count == 3,
              let mass = Int(parts[2]) else {
            return .unknown(raw: line)
        }
        return .container(code: parts[1], massKg: mass)
        
    case "livestock":
        guard parts.count == 4,
              let count = Int(parts[2]),
              let perUnit = Int(parts[3]) else {
            return .unknown(raw: line)
        }
        return .livestock(species: parts[1], count: count, massPerUnitKg: perUnit)
    default:
        return .unknown(raw: line)
    }
    
}

// 2.3
func mass(of entry: ManifestEntry) -> Int {
    switch entry {
    case .crate(_, let massKg):
        return massKg
    case .container(_, let massKg):
        return massKg
    case .livestock(_, let count, let massPerUnitKg):
        return count * massPerUnitKg
    case .unknown:
        return 0
    }
}

var totalMass = 0
var unknownCount = 0
for line in rawManifest {
    let entry = parseEntry(line)
    totalMass += mass(of: entry)
    if case .unknown = entry {
        unknownCount += 1
    }
}

print("Manifest total mass: \(totalMass) kg")
print("Unknown lines: \(unknownCount)")

let A = totalMass


// MARK: Level 3 · Crew Snapshots

// 3.1
struct CrewSnapshot {
    let name: String
    var deck: Deck
    var oxygen: Int
    
    mutating func breathe(_ amount: Int) {
        oxygen -= amount
        if oxygen < 0 {
            oxygen = 0
        }
    }
    
    mutating func move(to deck: Deck) {
        self.deck = deck
    }
    
    mutating func reviveInMedbay() {
        self = CrewSnapshot(name: name, deck: .medbay, oxygen: 100)
    }
    
    static func rookie(named name: String) -> CrewSnapshot {
        return CrewSnapshot(name: name, deck: .bridge, oxygen: 100)
    }
}

/*
 why you don't need one here but will need one in Level 4.
 Structs get a memberwise initializer for free — that's why CrewSnapshot didn't need one. Classes don't get one; Swift only gives a class a default init() if every stored property already has a default. Since id and chargeLevel have no defaults, we must write init ourselves and set every stored property (including occupant = nil).
 */

// 3.2
var crewRoster: [CrewSnapshot] = []
for record in crewData {
    guard let deck = Deck(rawValue: record.deck) else {
        print("Warning: unknown deck '\(record.deck)' for \(record.name) - skipped")
        continue
    }
    crewRoster.append(CrewSnapshot(name: record.name, deck: deck, oxygen: record.oxygen))
}

print("Roster built with \(crewRoster.count) crew members")

// 3.3 · Value-semantics demonstration (copy / plain parameter / inout)

// (1) Copy modified, original unchnaged
let original = crewRoster[0]
print("Initial  - original.oxygen = \(original.oxygen)")

var copy = original
copy.oxygen = 5
print("Before - original.oxygen = \(original.oxygen), copy oxygen = \(copy.oxygen)")

// (2) Plain function parameter - not inout
func drain(_ snapshot: CrewSnapshot) {
    var local = snapshot
    local.oxygen = 0
    print("Inside plain function, local oxygen: \(local.oxygen)")
}
print("Before - original.oxygen = \(original.oxygen)")
drain(original)
print("After plain function, original oxygen: \(original.oxygen)")

// (3) inout parameter
func drainInout(_ snapshot: inout CrewSnapshot) {
    snapshot.oxygen = 0
    print("Inside inout functio - snapshot.oxygen = \(snapshot.oxygen)")
}

var mutableOriginal = original
print("Before - mutableOriginal.oxygen = \(mutableOriginal.oxygen)")
drainInout(&mutableOriginal)
print("After inout function, original oxygen: \(mutableOriginal.oxygen)")

// MARK: Level 4 · The Teleport Pod

// 4.1
final class TeleportPod {
    let id: String
    var chargeLevel: Int
    var occupant: CrewSnapshot?
    
    /*
     why we write this init ourselves:
     CrewSnapshot is a Struct, so Swift gave it a free memberwise initializer. TeleportPod is a class: Swift never synthesizes a memberwise init for classes, and no default init() exists because id and chargeLevel have no defaults. So we write init ourselves and set all stored properties.
     */
    
    init(id: String, chargeLevel: Int) {
        self.id = id
        self.chargeLevel = chargeLevel
        self.occupant = nil
    }
    
    func load(_ crew: CrewSnapshot) -> Bool {
        if occupant != nil { return false }
        if chargeLevel < 20 { return false }
        occupant = crew
        return true
    }
    
    func fire() -> CrewSnapshot? {
        guard let crew = occupant else {
            return nil
        }
        chargeLevel -= 20
        occupant = nil
        return crew
    }
    // deinit runs automatically when the last reference to this pod is about to be destroyed. Only classes have dinit - structs and enums do not, because they are value types with no shared heap storage
    
    deinit {
        print("TeleportPod \(id) deinitialized")
    }
}

// 4.2 · Charge ledger: load+fire three times, then fire an empty pod
let pod = TeleportPod(id: "P-1", chargeLevel: 100)
print("Initial charge: \(pod.chargeLevel)")

let timur = crewRoster[0]
let dana = crewRoster[1]
let nurlan = crewRoster[3]

_ = pod.load(timur)
_ = pod.fire()
print("After Timur: \(pod.chargeLevel)")

_ = pod.load(dana)
_ = pod.fire()
print("After Dana: \(pod.chargeLevel)")

_ = pod.load(nurlan)
_ = pod.fire()
print("After Nurlan: \(pod.chargeLevel)")

_ = pod.fire()
print("After empty fire: \(pod.chargeLevel)")

let C = pod.chargeLevel

// 4.3 · Reference-semantics demonstration
let podRef1 = TeleportPod(id: "R-1", chargeLevel: 80)
let podRef2 = podRef1
podRef2.chargeLevel = 30
print("Pod ref1 charge: \(podRef1.chargeLevel), pod ref2 charge: \(podRef2.chargeLevel)")

var snap1 = CrewSnapshot.rookie(named: "Test")
let snap2 = snap1
snap1.oxygen = 10
print("Snapshot snap1 oxygen: \(snap1.oxygen), snap2 oxygen: \(snap2.oxygen)")

/*
 Rule: classes are reference types - assignment copies the reference, so both variables point to the same instance. Structs are value types - assignment copies the value, so each variable has its own independent copy.
 */

// MARK: Level 5 · Station Systems

// 5.1
@MainActor
final class Station {
    let callSign: String
    
    var hullIntegrity: Int {
        willSet {
            print("hullIntegrity: \(hullIntegrity) -> \(newValue)")
        }
        didSet {
            if hullIntegrity > 100 { hullIntegrity = 100 }
            if hullIntegrity < 0 { hullIntegrity = 0 }
        }
    }
    
    lazy var fullDiagnostics: String = {
            print("Running full scan...")
            var report = "Diagnostics for \(callSign):\n"
            for (deck, oxygen) in oxygenByDeck {
                report += "  \(deck.rawValue): \(oxygen)\n"
            }
            return report
    }()
    
    var oxygenByDeck: [Deck: Int]
    
    var totalOxygen: Int {
            var sum = 0
            for value in oxygenByDeck.values {
                sum += value
            }
            return sum
        }

    var averageOxygen: Int {
        get {
            if oxygenByDeck.isEmpty { return 0 }
            return totalOxygen / oxygenByDeck.count
        }
        set {
            for key in oxygenByDeck.keys {
                oxygenByDeck[key] = newValue
            }
        }
    }
    
    init(callSign: String, hullIntegrity: Int) {
            self.callSign = callSign
            self.hullIntegrity = hullIntegrity

            var readings: [Deck: Int] = [:]
            for reading in deckReadings {
                guard let deck = Deck(rawValue: reading.deck) else {
                    print("Warning: unknown deck '\(reading.deck)' in readings — skipped")
                    continue
                }
                readings[deck] = reading.oxygen
            }
            self.oxygenByDeck = readings
        }
}

let station = Station(callSign: "ALMA-7", hullIntegrity: 100)
let B = station.averageOxygen
print("Starting average oxygen: \(B)")

print("station address exists")
print(station)
print(station.callSign)

print("Before touching fullDiagnostics")
print(station.fullDiagnostics)
print(station.fullDiagnostics)


// 5.2 · The clamp trap: 130, then -40, then 55
station.hullIntegrity = 130
print("hullIntegrity after 130: \(station.hullIntegrity)")

station.hullIntegrity = -40
print("hullIntegrity after -40: \(station.hullIntegrity)")

station.hullIntegrity = 55
print("hullIntegrity after 55: \(station.hullIntegrity)")

/*
 the didSet clamps does not loop forever becuase assigning to a property inside its own didSet  does NOT re-trigger willSet or didSet - Swift deliberately bypasses the observers for that assignment. Without this rule, `didSet { self.x = ... }` would recurse infinitely.
 */

// MARK: Level 6 · Incident Reports
// Three of these compile and are wrong. One does not compile.
// For each: expectation, actual behaviour, the language rule, the fix.

/*
// Report 1
var roster = crewRoster
for var member in roster {
    member.oxygen -= 10
}
print(roster[0].oxygen)   // author expected the crew to have lost oxygen

// Report 2
let podA = TeleportPod(id: "A", chargeLevel: 100)
let podB = podA
podB.chargeLevel = 0
print(podA.chargeLevel)   // author expected 100

// Report 3
struct Logbook {
    var entries: [String] = []
    func add(_ entry: String) {
        entries.append(entry)
    }
}

// Report 4
let snapshot = CrewSnapshot.rookie(named: "Dana")
snapshot.oxygen = 40

let pod = TeleportPod(id: "B", chargeLevel: 50)
pod.chargeLevel = 10
*/

// Report 1 - for var memeber in roster
// Expected: roster[0].oxygen loses 10
// Actual: unchanged  - `for var member` copies each struct element.
// Rule: structs are value types; mutating the copy doesn't touch the array.
// Fix: loop over indices and mutate roster[i] directly.

var roster = crewRoster
for i in 0..<roster.count {
    roster[i].oxygen -= 10
}
print("Report 1 — roster[0].oxygen = \(roster[0].oxygen)")

// Report 2 - two lets pointing to the same pod
// Expected: podA.chargeLevel stays 100.
// Actual: becomes 0 — both reference the same instance.
// Rule: classes are reference types,  assignment copies the reference.
// Fix: accept the reference semantics

let podA = TeleportPod(id: "A", chargeLevel: 100)
let podB = podA
podB.chargeLevel = 0
print("Report 2 — podA.chargeLevel = \(podA.chargeLevel)")

// Report 3 - missing mutating on a struct method
// Expected: add appends to entries.
// Actual: compile error — "cannot use mutating member on immutable value".
// Rule: struct methods that mutate stored properties must be `mutating`.
// Fix: add the `mutating` keyword.

struct Logbook {
    var entries: [String] = []
    mutating func add(_ entry: String) {
        entries.append(entry)
    }
}
var log = Logbook()
log.add("First entry")
print("Report 3 — log.entries.count = \(log.entries.count)")

// Report 4 - let on struct vs let on class
// Expected: both assignments work.
// Actual: snapshot.oxygen = 40 is a compile error; pod.chargeLevel = 10 works.
// Rule: `let` on a struct freezes the entire value (all stored properties become read-only). `let` on a class freezes only the reference — the instance's `var` properties remain mutable.
// Fix: change `let snapshot` to `var snapshot`.

var snapshot = CrewSnapshot.rookie(named: "Dana")
snapshot.oxygen = 40
print("Report 4 — snapshot.oxygen = \(snapshot.oxygen)")

let reportPod = TeleportPod(id: "B", chargeLevel: 50)
reportPod.chargeLevel = 10
print("Report 4 — pod.chargeLevel = \(pod.chargeLevel)")


// MARK: Level 7 · Sealing the Black Box

// The leaky original:
//
// class FlightRecorder {
//     var entries: [String] = []
//     var isSealed = false
// }
//
// Your sealed version below. One comment per access keyword.

final class FlightRecorder {
    // private blocks ALL access to the storage fro outside the class and nobody can replace, clear, or directly read the raw entries array
    private var entries: [String] = []

    // private(set) readable from outside, but writable only from inside the class — outsiders cannot set isSealed back to false.
    private(set) var isSealed: Bool = false

    // internal (def) read-only count, so outsiders can see how many entries exist without touching the array itself.
    var entryCount: Int {
        return entries.count
    }

    // fileprivate only code in THIS FILE can produce the raw transcript. Used by the free function auditTranscript(of:) below.
    fileprivate func rawTranscript() -> String {
        var result = ""
        for entry in entries {
            result += entry + "\n"
        }
        return result
    }

    // internal (default) any code can read the formatted transcript. It routes through rawTranscript(), which is fileprivate.
    var formattedTranscript: String {
        return rawTranscript()
    }

    // internal (default) allowed only when the recorder is not sealed.
    func add(_ entry: String) {
        if isSealed { return }
        entries.append(entry)
    }

    // internal (default) seal once — cannot be undone.
    func seal() {
        isSealed = true
    }
}

// Free function elsewhere in the same file — uses the fileprivate helper.

func auditTranscript(of recorder: FlightRecorder) -> String {
    return recorder.rawTranscript()
}


// MARK: Finale · Integrity Code

let D = AlarmLevel.level(forTotalMass: A)
let integrityCode = "\(A)-\(B)-\(C)-\(D)"
print("INTEGRITY CODE: \(integrityCode)")


// MARK: Bonus

// deinit in TeleportPod, a do-block lifetime experiment, and === identity

// do-block lifetime experiment
var survivingPod: TeleportPod?

do {
    print("Entering do-block")
    let pod1 = TeleportPod(id: "BONUS-1", chargeLevel: 100)
    survivingPod = pod1
    let pod2 = pod1
    print("Inside do-block: pod1 = \(pod1.id), pod2 = \(pod2.id)")
    print("Leaving do-block")
}

print("After do-block")
print("survivingPod still alive: \(survivingPod?.id ?? "none")")

survivingPod = nil
print("After clearing survivingPod")

// deinit fires on `survivingPod = nil`, not at the do-block's closing brace. When pod1 and pod2 go out of scope, survivingPod still holds a strong reference, so ARC keeps the instance alive (ref count = 1). Only when the last reference is cleared does the count hit 0 and deinit run

// ===identity
func isSamePod(_ a: TeleportPod, _ b: TeleportPod) -> Bool {
    return a === b
}

func describeIdentity(_ a: TeleportPod, _ b: TeleportPod) -> String {
    if a === b {
        return "Same instance (id: \(a.id))"
    } else {
        return "Different instances (a.id = \(a.id), b.id = \(b.id))"
    }
}

let podX = TeleportPod(id: "X", chargeLevel: 100)
let podY = TeleportPod(id: "X", chargeLevel: 100)
let podZ = podX

print(describeIdentity(podX, podY))
print(describeIdentity(podX, podZ))
print("podX === podY: \(isSamePod(podX, podY))")
print("podX === podZ: \(isSamePod(podX, podZ))")

//=== cannot be used on CrewSnapshot because it is a struct (value type). === compares memory addresses (identity) and works only on classes. Structs have no fixed address — every assignment copies the value. Use == with Equatable conformance to compare CrewSnapshot values instead.



// MARK: - ================= DEFENSE QUESTIONS =================
/*
 1. Why did CrewSnapshot get an initializer for free and TeleportPod did not?
 Structs get a free memberwise init. Classes never do and no default init() exists unless every property already has a default. id and chargeLevel have none, so we wrote init ourselves.
 
 2. What does `mutating` do to self, and why do classes never need it?
 Mutating makes self writable in struct/enum methods. Classes don't need it because self  is already a reference to shared storage.

 3. In Report 4 both values are `let`. What exactly does `let` freeze for a struct, and what does it freeze for a class?
 For a struct, the entire value, every property becomes read-only
 For a class, only the reference, the instance's var properties stay mutable
 
 4. Why must a lazy property be var? When does lazy change behaviour, not just performance?
 Lazzy assigns after init, so it must be var. it changes behaviour when the initial value has side effects that should only happen once and only is the property is used.

 5. private vs fileprivate: where in your FlightRecorder would private be too strict?
 rawTranscript() is called by the free function auditTranscript(of:) in the same file. private would block it, fileprivate allows it
 
 3.1 why you don't need one here but will need one in Level 4.
  Structs get a memberwise initializer for free — that's why CrewSnapshot didn't need one. Classes don't get one; Swift only gives a class a default init() if every stored property already has a default. Since id and chargeLevel have no defaults, we must write init ourselves and set every stored property (including occupant = nil).


 Bonus. On which line does deinit fire, and why can't === be used on CrewSnapshot?
 === cannot be used on CrewSnapshot because it is a struct (value type).
 === compares memory addresses (identity) and works only on classes.
 Structs have no fixed address — every assignment copies the value.
 Use == with Equatable conformance to compare CrewSnapshot values instead.

*/

