// =============================================================
//  Station ALMA-7: Rescue Protocol
//  iOS Mobile Development · Module 3 · Lab Assignment
//
//  How to use:
//   • Xcode: File → New → Playground → Blank, replace everything
//     with this file's contents.
//   • Terminal: swift ALMA7_Starter.swift
//
//  Rules:
//   • Do NOT modify the STARTER CODE section.
//   • `!` (force unwrap) is forbidden: −0.5 points each.
//   • No map / filter / reduce / compactMap.
//   • Use the exact function names from the assignment PDF.
// =============================================================


// MARK: - =================== STARTER CODE ===================
// MARK: - Do not modify anything in this section

typealias Reading = (sensor: String, value: Int)

/// Splits a string at the first occurrence of the separator.
/// splitOnce("O2:87", by: ":") -> ("O2", "87")
/// splitOnce("hello", by: ":") -> nil
func splitOnce(_ line: String, by separator: Character) -> (String, String)? {
    guard let index = line.firstIndex(of: separator) else { return nil }
    let left = String(line[..<index])
    let right = String(line[line.index(after: index)...])
    return (left, right)
}

let rawLog = [
    "O2:87", "TEMP:-12", "O2:9x", "PRESS:101", "TEMP:abc", "O2:",
    "RAD:3", "O2:64", ":55", "TEMP:31", "PRESS:98", "O2:71",
    "RAD:-1", "TEMP:4", "PRESS:1o2", "O2:90"
]

class Tank {
    var level: Int
    init(level: Int) { self.level = level }
}

class Module {
    let name: String
    var oxygenTank: Tank?
    init(name: String, oxygenTank: Tank?) {
        self.name = name
        self.oxygenTank = oxygenTank
    }
}

class CrewMember {
    let name: String
    let role: String
    let priority: Int      // 1 = evacuated first
    var module: Module?    // nil = in open space
    init(name: String, role: String, priority: Int, module: Module?) {
        self.name = name
        self.role = role
        self.priority = priority
        self.module = module
    }
}

let lab  = Module(name: "Lab",  oxygenTank: Tank(level: 40))
let hab  = Module(name: "Hab",  oxygenTank: Tank(level: 12))
let dock = Module(name: "Dock", oxygenTank: nil)

let crew = [
    CrewMember(name: "Timur",   role: "Engineer",  priority: 3, module: lab),
    CrewMember(name: "Dana",    role: "Scientist", priority: 4, module: dock),
    CrewMember(name: "Aigerim", role: "Commander", priority: 1, module: hab),
    CrewMember(name: "Nurlan",  role: "Pilot",     priority: 2, module: nil)
]

var roster: [String: CrewMember] = [:]
for member in crew { roster[member.name] = member }

print("ALMA-7 systems online: \(rawLog.count) log lines, \(crew.count) crew members.")

// MARK: - ================= END OF STARTER CODE =================


// MARK: - =================== YOUR SOLUTION ===================
// Uncomment each signature when you start working on it.


// MARK: Level 1 · Decoding Telemetry

// 1.1
import Foundation
func parseReading(_ raw: String) -> Reading? {
    guard let parts = splitOnce(raw, by: ":"),
          !parts.0.isEmpty,
          let value = Int(parts.1.trimmingCharacters(in: .whitespaces)),
          value >= 0 || parts.0 == "TEMP"
    else { return nil }
    return (sensor: parts.0, value: value)
}

print(parseReading("O2:87") ?? "nil")
print(parseReading("TEMP:-12") ?? "nil")

// 1.2
func parseLog(_ lines: [String]) -> (valid: [Reading], invalidCount: Int) {
    var valid: [Reading] = []
    var invalidCount = 0
    for line in lines {
        if let reading = parseReading(line) {
            valid.append(reading)
        } else { invalidCount += 1 }
    }
    
    return (valid: valid, invalidCount: invalidCount)
}

let parsed = parseLog(rawLog)
print(parsed.valid)
print(parsed.invalidCount)

let A = parsed.invalidCount
print("A =", A)


// MARK: Level 2 · Analysis

// 2.1
func select(_ readings: [Reading], where isIncluded: (Reading) -> Bool) -> [Reading] {
    var result: [Reading] = []
    for reading in readings {
        if isIncluded(reading) {
            result.append(reading)
        }
    }
    return result
}

func values(of readings: [Reading]) -> [Int] {
    var result: [Int] = []
    for reading in readings {
        result.append(reading.value)
    }
    return result
}

let o2Readings = select(parsed.valid) {$0.sensor == "O2"}
print(o2Readings)

let o2Values = values(of: o2Readings)
print(o2Values)

// 2.2
func stats(of values: [Int]) -> (min: Int, max: Int, average: Double)? {
    guard !values.isEmpty else { return nil }
    var minVal = values[0]
    var maxVal = values[0]
    var sum = 0
    for val in values {
        if val < minVal { minVal = val}
        if val > maxVal { maxVal = val}
        sum += val
    }
    
    let average = Double(sum) / Double(values.count)
    return (min: minVal, max: maxVal, average: average)
}

print(stats(of: [3, 8, 1]) ?? "nil")
print(stats(of: [10, 20]) ?? "nil")
print(stats(of: [] ) ?? "nil")

func stats(_ values: Int...) -> (min: Int, max: Int, average: Double)? {
    stats(of: values)
}

let B = Int(stats(of: o2Values)?.average ?? 0)
print("B =", B)


// 2.3 · The Closure Ladder (5 sorts, then compare results in code)
// Full closure syntax with types and return

let s1 = parsed.valid.sorted(by: { (a: Reading, b: Reading) -> Bool in return a.value > b.value })

// Types inferred from context
let s2 = parsed.valid.sorted(by: {a, b in return a.value > b.value})


// Implicit return
let s3 = parsed.valid.sorted(by: {a, b in a.value > b.value })

// Shorthand argument names $0 , $1
let s4 = parsed.valid.sorted(by: { $0.value > $1.value })

// Trailing closure
let s5 = parsed.valid.sorted { $0.value > $1.value }

print(values(of: s1))
print(values(of: s2))
print(values(of: s3))
print(values(of: s4))
print(values(of: s5))

let v1 = values(of: s1)
let v2 = values(of: s2)
let v3 = values(of: s3)
let v4 = values(of: s4)
let v5 = values(of: s5)

print("s1 == s2:", v1 == v2)
print("s2 == s3:", v2 == v3)
print("s3 == s4:", v3 == v4)
print("s4 == s5:", v4 == v5)

// MARK: Level 3 · Temperature Stabilization

// 3.1
func heatUp(_ t: Int) -> Int {
    return t + 5
}
func coolDown(_ t: Int) -> Int {
    return t - 3
}
func hold(_ t: Int) -> Int {
    return t
}
func chooseProtocol(for temp: Int) -> (Int) -> Int {
    if temp < 18 {return heatUp}
    if temp > 24 { return coolDown}
    return hold
}

print(heatUp(10))
print(coolDown(10))
print(hold(10))
print(chooseProtocol(for: 10)(10))
print(chooseProtocol(for: 30)(30))
print(chooseProtocol(for: 20)(20))

// 3.2
func runUntilStable(from start: Int, maxSteps: Int = 10) -> (finalTemp: Int, steps: Int, isStable: Bool) {
    var temp = start
    var steps = 0
    while (temp < 18 || temp > 24) && steps < maxSteps {
        let action = chooseProtocol(for: temp)
        temp = action(temp)
        steps += 1
    }
    let isStable = temp >= 18 && temp <= 24
    return (finalTemp: temp, steps: steps, isStable:isStable)
}

print(runUntilStable(from: 20))
print(runUntilStable(from: 31))
print(runUntilStable(from: -100, maxSteps: 5))

let tempReadings = select(parsed.valid) {$0.sensor == "TEMP"}
let tempValues = values(of: tempReadings)
let tempStats = stats(of: tempValues)
let lowestTemp = tempStats?.min ?? 0

print("Lowest temp:", lowestTemp)

let C = runUntilStable(from: lowestTemp).steps
print("C =", C)


// MARK: Level 4 · The Crew

// 4.1
func oxygenLevel(of member: CrewMember) -> Int? {
    return member.module?.oxygenTank?.level
}

print(oxygenLevel(of: crew[0]) ?? "nil")
print(oxygenLevel(of: crew[1]) ?? "nil")
print(oxygenLevel(of: crew[2]) ?? "nil")
print(oxygenLevel(of: crew[3]) ?? "nil")


// 4.2
func status(of member: CrewMember) -> String {
    guard let level = oxygenLevel(of: member) else {
        let place = member.module?.name ?? "open space"
        return "\(member.name): no data (\(place))"
    }
    if level < 20 {
        return "\(member.name): \(level)% CRITICAL"
    }
    return "\(member.name): \(level)% OK"
}

for member in crew {
    print(status(of: member))
}

// 4.3
@discardableResult
func transferOxygen(from source: inout Int, to target: inout Int, amount: Int) -> Int {
    if amount <= 0 { return 0 }
    let available = source
    let capacity = 100 - target
    let actual = min(amount, min(available, capacity))
    source -= actual
    target += actual
    return actual
}

var labLevel = lab.oxygenTank?.level ?? 0
var habLevel = hab.oxygenTank?.level ?? 0

print("Before: Lab =", labLevel, ", Hab =", habLevel)

let transferred = transferOxygen(from: &labLevel, to: &habLevel, amount: 30)
print("Transferred:", transferred)

lab.oxygenTank?.level = labLevel
hab.oxygenTank?.level = habLevel

print("After: Lab =", labLevel, ", Hab =", habLevel)

var a = 50
var b = 50
let t2 = transferOxygen(from: &a, to: &b, amount: -10)
print("t2 =", t2, ", a =", a, ", b =", b)

let D = habLevel
print("D =", D)

// 4.4
func evacuationOrder(_ names: String..., roster: [String: CrewMember]) -> [String] {
    var members: [CrewMember] = []
    for name in names {
        if let member = roster[name] {
            members.append(member)
        }
        
    }
    let sorted = members.sorted { $0.priority < $1.priority }
    var result: [String] = []
    for member in sorted {
        result.append(member.name)
    }
    return result
}

print(evacuationOrder("Timur", "Dana", "Aigerim", "Nurlan", roster: roster))
print(evacuationOrder("Nurlan", "Aigerim", roster: roster))
print(evacuationOrder("Aigerim", "Unknown", "Timur", roster: roster))


// MARK: Level 5 · The Saboteur's Logbook
// The saboteur's code is below, commented out (it needs your
// oxygenLevel(of:) to compile). Comment on every problem, then
// write fixed versions and a test that proves the logic bug is gone.

/*
func reportOxygen(for member: CrewMember) -> String {
    let tank = member.module!.oxygenTank!
    return "\(member.name): \(tank.level)%"
}

func firstCritical(in crew: [CrewMember]) -> String {
    var result: String?
    for member in crew {
        if oxygenLevel(of: member)! < 20 {
            result = member.name
        }
    }
    return result!
}
*/

/*
 1. member.module! - force unwrap of the optional Module?
 What breaks it: Nurlan (module == nil, he is in open space)
 What happens: Fatal error "Unexpectedly found nil while unwrapping
 an optional value" and the program crashes
 
 2. member.module!.oxygenTank! — second force unwrap, now Tank?
 What breaks it: Dana (module = Dock, but oxygenTank == nil,
 the Dock has no tank)
 What happens: same fatal error
 
 3. oxygenLevel(of: member)! — force unwrap of Int?
 What breaks it:  Nurlan and Dana (oxygenLevel returns nil)
 What happens: fatal error
 
 4. Logic bug (NOT !): in firstCritical the loop does not stop,
 so result gets overwritten for every critical member
 It returns the LAST critical member, not the FIRST, as the name promises. It is not visible with the starter data because only Aigerim is critical
 
 5. return result! — force unwrap of String?.
 Data that breaks it: a crew where nobody is critical (all levels
 >= 20 or everyone has no data). result stays nil
 What happens: fatal error
 */


// Fixed version
func reportOxygen(for member: CrewMember) -> String {
    guard let tank = member.module?.oxygenTank else {
        return "\(member.name): no data"
    }
    return "\(member.name): \(tank.level)%"
}

func firstCritical(in crew: [CrewMember]) -> String? {
    for member in crew {
        if let level = oxygenLevel(of: member), level < 20 {
            return member.name
        }
    }
    return nil
}

print(reportOxygen(for: crew[0]))
print(reportOxygen(for: crew[1]))
print(reportOxygen(for: crew[2]))
print(reportOxygen(for: crew[3]))

print(firstCritical(in: crew) as Any)
print(firstCritical(in: []) as Any)

let safeTank = Tank(level: 50)
let safeModule = Module(name: "Safe", oxygenTank: safeTank)
let safeCrew = [CrewMember(name: "Safe", role: "Test", priority: 1, module: safeModule)]
print(firstCritical(in: safeCrew) as Any)

let testTank1 = Tank(level: 10)
let testTank2 = Tank(level: 5)
let testModule1 = Module(name: "Test1", oxygenTank: testTank1)
let testModule2 = Module(name: "Test2", oxygenTank: testTank2)
let criticalCrew = [
    CrewMember(name: "FirstCritical",  role: "Test", priority: 1, module: testModule1),
    CrewMember(name: "SecondCritical", role: "Test", priority: 2, module: testModule2)
]
let criticalResult = firstCritical(in: criticalCrew)
print("First critical (should be FirstCritical): \(criticalResult as Any)")
assert(criticalResult == "FirstCritical", "Logic bug: firstCritical returned the wrong member")
print("Logic bug fixed ")

// MARK: Finale · Launch Code

let launchCode = "\(A)-\(B)-\(C)-\(D)"
print("LAUNCH CODE: \(launchCode)")


// MARK: Bonus

func makeAlarm(threshold: Int) -> (Int) -> Bool {
    var count = 0
    return { level in
        if level < threshold {
            count += 1
            print("Alarm #\(count)")
            return true
        }
        return false
    }
}

let alarm = makeAlarm(threshold: 20)
print(alarm(12))
print(alarm(40))
print(alarm(5))


// MARK: - ================= DEFENSE QUESTIONS =================
/*
 1. guard let vs if let beyond syntax:
 if let - value only inside the if block, guard let - value for the rest of the function, and exits early if nil. guard let keeps code flat, so it is better when you need the value to continue.
 For example: where if let is worse: 50 lines of logic all indented inside if let, instead of staying at the top level guard let.

 2. Why can't you pass [Int] to stats(_ values: Int...)?
 Int... takes many separate numbers, not the array
 Use stats(of: someArray) instead

 3. Why doesn't transferOxygen(from: &x, to: &x, amount: 5) compile?
 swift forbids passing the same variable as two inout parameters - it would read and write the same memory at once.

 4. Why doesn't oxygenLevel(of: dana) ?? "no data" compile?
 oxygenLevel returns Int?, "no data" is String - types must match for ??.
 Convert first: oxygenLevel(of: dana).map  { "\($0)" } ?? "no data"

 5. Full type of chooseProtocol and how to read it:
 (Int) -> ((Int) -> (Int))
 takes an Int, returns a function that takes an Int and returns an Int

 Bonus. Where does the alarm counter live after makeAlarm returns?
 in a heap box captured by the closure, it stays alive as long as the closure does. so it keeps counting after makeAlarm returns

*/

